<?php
echo 'Something is wrong with database connection, please verify the credentials.';
?>